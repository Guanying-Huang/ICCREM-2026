# Building Information Knowledge Graph (BI-KG) Construction for BER

This repository contains the source code for constructing a Building Information Knowledge Graph (BI-KG) from as-built BIM data (IFC format) and operational records, tailored for the Decision Support System (DSS) of Building Energy Retrofit (BER).

Based on the mapping mechanism established in the methodology, this codebase translates native IFC topologies into an explicitly structured semantic framework. It acts as the foundational data source for the "Building Explorer" agent within the LLM-driven multi-agent system (MAS).

## 🚀 Semantic Schema & Topology

The graph maps physical and spatial entities from IFC files while injecting operational parameters (e.g., IEQ records, utility bills), achieving cross-domain data integration.

### Graph Characteristics (Case Building - Badminton Hall)
* **Total Nodes**: 203
* **Total Relationships**: 273

### Entity Types (Nodes)
1. **Case Building** (Black): The overarching global node representing the building project (`IfcProject`/`IfcBuilding`). (1 node)
2. **Thermal Space** (Green): Internal spaces and the explicitly defined `Outdoor` anchor node (`IfcSpace`, `IfcTransportElement`). (11 nodes)
3. **Passive Envelope** (Red/Coral): Mapped from `IfcWall`, `IfcWindow`, `IfcDoor`, `IfcRoof`, `IfcSlab`. (133 nodes)
4. **Active Equipment** (Blue): Mapped from `IfcUnitaryEquipment`, `IfcHeatExchanger`, `IfcTransformer`, `IfcLightFixture`. (58 nodes)
5. **Energy Generator**: Mapped from `IfcSolarDevice`, `IfcPump`, `IfcBoiler`, `IfcSensor`.

### Relationship Types (Edges / Triples)
* **Contains**: Connects `Case Building` to `Thermal Space` (including the Outdoor node). (10 relationships)
* **Bounds**: Links `Passive Envelope` to `Thermal Space`. (205 relationships)
* **Serves**: Links `Active Equipment` to `Thermal Space`. (58 relationships)
* **Powers**: Links `Energy Generator` to `Active Equipment`.

## 📁 Repository Structure

* `01_ifcextraction.py`: Custom IFC2KG algorithm. Parses the IFC object hierarchy, extracts Psets/Qtos, injects operational data, and defines semantic mappings.
* `02_kgconstruction.py`: Instantiates the formal, directed BI-KG using `networkx` and prepares it for Neo4j ingestion.
* `03_BIKG_visualization.py`: Generates a high-fidelity interactive HTML visualization matching the color schema of Figure 5(a) in the manuscript.
* `04_GraphRetrievalTools.py`: Cypher-based retrieval functions tailored for the LLM function calling of the Building Explorer agent.