import json
from neo4j import GraphDatabase

class BuildingExplorerTools:
    """
    Building Explorer Agent 专属图检索工具类。
    封装了基于 Cypher 语句的 Neo4j 查询逻辑，支撑 LLM-driven MAS 执行建筑能耗改造（BER）的空间和资产信息提取。
    """
    
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def get_ifc_entity_properties(self, entity_type, property_name):
        """1. 提取特定 IFC 实体（如 IfcLightFixture）的参数与能耗属性"""
        # ... (内部代码与之前保持一致，查询 n.raw_properties) ...
        pass

    def get_elements_serving_space(self, space_name, element_category):
        """
        2. 获取服务于特定热区（Thermal Space）的设备。
        逻辑：检索 [Active Equipment]-[:Serves]->[Thermal Space] 关系。
        """
        query = """
        MATCH (e)-[r:Serves]->(s:Thermal Space {label: $space_name})
        WHERE e.type = $element_category
        RETURN e.id AS id, e.ifc_type AS ifc_type
        """
        # ... (执行逻辑与原版类似) ...
        pass